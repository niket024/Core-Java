package com.nik.nosql;

public class NoSqlManagerTest {

	public void testNewEntry() {

	}

	public void testExistingEntry() {

	}

	public void testStringDataType() {

	}

	public void testIntgerDataType() {

	}

	public void testDoubleDataType() {

	}

	public void testIntegerDataType() {

	}

	public void testDeleteKey() {

	}

	public void testPutKey() {

	}

	public void testIndex() {

	}
}
